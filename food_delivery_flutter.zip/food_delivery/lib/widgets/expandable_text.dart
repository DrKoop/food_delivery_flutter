import 'package:flutter/material.dart';
import 'package:food_delivery/utils/colors.dart';
import 'package:food_delivery/utils/dimensions.dart';
import 'package:food_delivery/widgets/small_text.dart';

class ExpandableTextWidget extends StatefulWidget {
  final String text;
  final Color color;
  const ExpandableTextWidget({super.key, required this.text, required this.color, });

  @override
  State<ExpandableTextWidget> createState() => _ExpandableTextWidgetState();
}

class _ExpandableTextWidgetState extends State<ExpandableTextWidget> {
  //Partes del textp y condiciones
  late String firstHalf;
  late String secondHalf;
  bool hiddenText = true;
  double textHeight = Dimensions.screenHeight/5.63;

  @override
  void initState(){
    super.initState();
    //Verificando el largo del texto, para que basado en ello, se oculte o se imprima el texto completo ( si el texto completo es corto)
    if( widget.text.length>textHeight ){
      firstHalf = widget.text.substring(0 ,textHeight.toInt());
      //Imprime el texto completo
      secondHalf = widget.text.substring( textHeight.toInt()+1, widget.text.length);
    }else{
      firstHalf = widget.text;
      secondHalf = "";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: secondHalf.isEmpty?SmallText(text: firstHalf,  size: Dimensions.font16,):Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          //Evalua e Imprime una descripcion corta o completa  del producto...
          SmallText(
            height: 1.5,
            size: Dimensions.font16,
            text: hiddenText?(firstHalf+"..."):(firstHalf+secondHalf),
            color: AppColors.mainBlackColor,
            ),
          InkWell(
            onTap: () {
              setState(() {
                hiddenText=!hiddenText;
              });
            },
            child:Row(
              children: [
                SmallText(text: 'Leer Más...', color: AppColors.mainBlackColor,),
                Icon( hiddenText?Icons.arrow_drop_down:Icons.arrow_drop_up, color: AppColors.mainColor,)
              ],
            ),)
        ],
      ),
    );
  }
}