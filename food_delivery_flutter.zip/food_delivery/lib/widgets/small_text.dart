

import 'package:flutter/cupertino.dart';
import 'package:food_delivery/utils/colors.dart';

class SmallText extends StatelessWidget {
  /* -------------------------------------------------------------------------- */
  /*    VARIABLES DINAMICAS PARA REUTILIZAR EN TODOS LOS CONTENEDORES-VISTAS    */
  /* -------------------------------------------------------------------------- */
  Color? color;
  final String text;
  double size;
  double height;

  SmallText({
    super.key,
    this.color = const Color(0xffccc7c5),
    required this.text,
    this.size = 12,
    this.height = 1.2,
    });

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        fontFamily: 'Roboto',
        color: color,
        fontSize: size,
        height: height,
      ),
    );
  }
}