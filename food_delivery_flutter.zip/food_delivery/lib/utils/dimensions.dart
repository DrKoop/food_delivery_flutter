import 'package:get/get.dart';

/* -------------------------------------------------------------------------- */
/*      ADAPTANDO EL CONTENIDO DE MANERA UNIFORME A CUALQUIER DIPOSITIVO      */
/* -------------------------------------------------------------------------- */

class Dimensions{

  static double screenHeight = Get.context!.height;
  static double screenWidth = Get.context!.width;
  static double pageView = screenHeight/2.64;
  static double pageViewContainer = screenHeight/3.84;
  static double pageViewTetxtContainer = screenHeight/7.03;
  // altura dinamica padding y margin
  //contenedor altura 10
  static double height10 = screenHeight/84.4;
  //altura top 15
  static double height15 = screenHeight/56.27;
  //contenedor altura 20
  static double height20 = screenHeight/42.2;
    //contenedor altura 30
  static double height30 = screenHeight/28.13;
  //contenedor altura 45
  static double height45 = screenHeight/18.76;

    // ancho dinamina padding y margin
  //contenedor ancho 10
  static double width10 = screenHeight/84.4;
  //ancho top 15
  static double width15 = screenHeight/56.27;
  //contenedor ancho 20
  static double width20 = screenHeight/42.2;
    //contenedor ancho 30
  static double width30 = screenHeight/28.13;

  //tamaño fuentes, dinamicos
  static double font16 = screenHeight/52.75;
  static double font20 = screenHeight/42.2;
  static double font26 = screenHeight/32.46;

  static double radius15 = screenHeight/56.27;
  static double radius20 = screenHeight/42.2;
  static double radius30 = screenHeight/28.13;

  //Tamaño iconos
  static double iconSize24 = screenHeight/35.17;
  static double iconSize16 = screenHeight/52.75;

  //List view size
  static double ListViewImgSize = screenWidth/3.25;
  static double ListViewTextContSize = screenWidth/3.9;

  //contenedores y textos del screen popular food
  static double popularFImgSize = screenHeight/ 2.41;

  //Tamaño dinamico boton  details - Food
  static double bottomHeightBar = screenHeight/7.03;

}