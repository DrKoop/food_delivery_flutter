
/* -------------------------------------------------------------------------- */
/*      SE CREA ESTE ARCHIVO CON VARIABLES QUE SE UTILIZAN CONSTANTEMENTE     */
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
/*      EN LOS MODELOSY CONTROLADORES PARA EVITAR ESTAR ( HARDCODEADOS )      */
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
/*            PARA DARLE UNA MAYOR PRESENTACION Y CALIDAD AL CODIGO           */
/* -------------------------------------------------------------------------- */

class AppConstants{
  //cambiar el nombre de la app en algun futuro , con otro proyecto
  static const String APP_NAME = 'DBFood';
  static const int APP_VERSION = 1;

  static const String BASE_URL = 'http://192.168.1.96:8001';
  static const String POPULAR_PRODUCT_URI = '/api/v1/products/popular';
  static const String RECOMMENDED_PRODUCT_URI = '/api/v1/products/recommended';
  static const String UPLOAD_URL = '/uploads/';

  //auth endpoints
  static const String REGISTRATION_URI = '/api/v1/auth/register';
  static const String LOGIN_URI = '/api/v1/auth/login';
  static const String USER_INFO = '/api/v1/customer/info';

  static const String TOKEN = '';
  static const String PHONE = '';
  static const String PASSWORD= '';

  static const String CART_LIST = 'cart-list';

  static const String CART_HISTORY_LIST = 'cart-history-list';
}