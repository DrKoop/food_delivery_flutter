

class SignUpBody{
  String name;
  String phone;
  String email;
  String password;

  /* -------------------------------------------------------------------------- */
  /*                                 CONSTRUCTOR                                */
  /* -------------------------------------------------------------------------- */
  
  SignUpBody({
    required this.name,
    required this.phone,
    required this.email,
    required this.password
  });

  //Convert data to Json
  Map<String, dynamic> toJson(){
    final Map<String, dynamic> data = new Map<String, dynamic>();
    //Nombre de las  columnas que seran insertadas en una BD - SQL
    data["f_name"] = this.name;
    data["phone"] = this.phone;
    data["email"] = this.email;
    data["password"] = this.password;
    return data;
  }

}