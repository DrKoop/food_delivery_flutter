

import 'package:food_delivery/controllers/cart_controller.dart';
import 'package:food_delivery/data/repository/popular_product_repo.dart';
import 'package:food_delivery/models/cart_model.dart';
import 'package:food_delivery/models/products_model.dart';
import 'package:get/get.dart';
import 'package:alert/alert.dart';

class PopularProductController extends GetxController{

  //Variable - instancias donde nos comunicamos con nuestro servicios y accedemos a todos sus metodos..
  final PopularProductRepo popularProductRepo;

  PopularProductController({required this.popularProductRepo});

  List<dynamic> _popularProductList = [];

  List<dynamic> get popularProductList => _popularProductList;

  bool _isLoadaded = false;
  bool get isLoaded => _isLoadaded;

  //boton incrementa - decrementa
  int _quantity=0;
  int get quantity {
    return _quantity;
  }

  //Salvar en memoria preferencias del usuario (items)
  int _inCartItems = 0;
  int get inCartItems => _inCartItems + _quantity;

  late CartController _cart;

  /* -------------------------------------------------------------------------- */
  /*         CONSUMO API + COMUNICACION ENTRE EL CONTROLADOR Y EL MODELO        */
  /* -------------------------------------------------------------------------- */
  Future<void> getPopularProductList() async{
    //recibiendo las respuesta, del metodo GEt, del servicio 
    Response response = await popularProductRepo.getPopularProductList();
    if( response.statusCode == 200){
      //print('Consumo api correctO');
      //Si se consumio el endpoint de manera correcta, guarda la respuesta en la variable privada
      _popularProductList = [];
      _popularProductList.addAll(Product.fromJson(response.body).products);
      //print(_popularProductList);
      _isLoadaded = true;
      update();
    }else{

    }
  }
  /* -------------------------------------------------------------------------- */
  /*         CONSUMO API + COMUNICACION ENTRE EL CONTROLADOR Y EL MODELO        */
  /* -------------------------------------------------------------------------- */


  /* -------------------------------------------------------------------------- */
  /*                           BOTON INCREMENTA / + -                           */
  /* -------------------------------------------------------------------------- */
  void setQuantity( bool isIncrement){
    if(isIncrement){
      
      _quantity = checkQuantity(_quantity+1);
      //print("incremento " + _quantity.toString());
    }else{
      _quantity = checkQuantity(_quantity-1);
      //print("se resto 1 item " + _quantity.toString());
    }
    update();
  }

/* -------------------------------------------------------------------------- */
/*                              REVISA CANTIDADES                             */
/* -------------------------------------------------------------------------- */
  int checkQuantity( int quantity){
    if((_inCartItems + quantity)<0){
      //Si la cantidad es MENOR que 0, retorna el valor a 0 ( asi se omite el ingreso de numero negativos)
      Get.snackbar('ALERTA !', 'No hay mas productos disponibles.');

      if(_inCartItems>0){
        _quantity = _inCartItems;
        return _quantity;
      }

      return 0;
      //return Alert(message: 'Test', shortDuration: true).show();
    }else if( (_inCartItems + quantity) > 20){
      Get.snackbar('ALERTA !', 'No puedes añadir mas productos.');
      return 20;
    }else{
      //si no es menor que 0 o mayor que 20 , regresamos la cantidad elegida por el usuario
      return quantity;
    }
  }


/* -------------------------------------------------------------------------- */
/*             SALVA EN MOMORIA items POR CADA ARTICULO INDIVIDUAL            */
/* -------------------------------------------------------------------------- */
  void initProduct(ProductModel product,CartController cart){
    _quantity = 0;
    _inCartItems = 0;
    _cart = cart;
    var exist = true;
    exist = _cart.existInCart(product);
    //print('Se agrego un item' + exist.toString());
    if(exist){
      _inCartItems = _cart.getQuantity(product);
    }
    //print('la cantidad de items en el carrito son: ' + _inCartItems.toString());
  }


  void addItem( ProductModel product){
    /* if(_quantity>0){ */
      _cart.addItem(product, _quantity);
      /* -------------------------------------------------------------------------- */
      /*                    *importante reiniciar la variable a 0                   */
      /* -------------------------------------------------------------------------- */
      //=> por que sumara infinitamente los items seleccionados
      _quantity = 0;
      //resolviendo el problema de que al restar productos, se RESETEA el contador a 0
      _inCartItems = _cart.getQuantity(product);

      _cart.items.forEach((key, value) {
          //print('el id es '+value.id.toString()+ 'la cantidad es '+value.quantity.toString() );
      });

    /* } *//* else{
      Get.snackbar('ALERTA !', 'Necesitas agregar almenos 1 producto.');
    }
     */
    update();
  }


  int get totalItems{
    return _cart.totalItems;
  }

  List<CartModel> get getItems{
    return _cart.getItems;
  }

}