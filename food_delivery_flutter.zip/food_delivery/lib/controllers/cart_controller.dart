

import 'package:food_delivery/data/repository/cart_repo.dart';
import 'package:food_delivery/models/cart_model.dart';
import 'package:food_delivery/models/products_model.dart';
import 'package:get/get.dart';

class CartController extends GetxController{
 //Comunicando a nuestro controlador con nuestro archivo en repo
 final CartRepo cartRepo;

  CartController({ required this.cartRepo});

  /* -------------------------------------------------------------------------- */
  /*                   EN ESTE MAP,(NOTESE ES UN OBJETO VACIO)                  */
  /* -------------------------------------------------------------------------- */
  /* -------------------------------------------------------------------------- */
  /*              SE GUARDARAN TODAS LAS PREFERENCIAS DEL USUARIO)              */
  /* -------------------------------------------------------------------------- */
  Map<int, CartModel> _items= {};


  //Map creado para debuggear , el modelo actualizado ...
  Map<int , CartModel> get items => _items;


  //Guardando data en localStorgae
  List<CartModel> storageItems = [];

    
    //AÑADE LOS ITEMS AL PRESIONAR EL BOTON AÑADIR AL CARRITO => se guarda todo este objeto, dentro de => _items= {};
    void addItem(ProductModel product, int quantity){

      var totalQuantity = 0;

      //print(' la cantidad del producto es:  ' + _items.length.toString() );

      //Actualizando el numero de items
      if(_items.containsKey(product.id!)){
        _items.update(product.id!, (value) {

        totalQuantity = value.quantity! + quantity;

        return CartModel(
        id       : value.id,
        name     : value.name,
        price    : value.price,
        img      : value.img,
        quantity : value.quantity!+quantity, //esta variable ya la estamos pasando como argumento, dentro de esta funcion
        isExist  : true,
        time     : DateTime.now().toString(),
        product: product,
        );
        });

        if(totalQuantity<=0){
          _items.remove(product.id);
        }
      }else{
        //Añadiendo item's
        if(quantity>0){
            _items.putIfAbsent( product.id! , () { 
              //print('producto añadido ala bd /modelo  ' + product.id!.toString() + quantity.toString() );

              //_items.forEach((key, value) {
                //print('la cantidad es  ' + value.quantity.toString());
              //});

              return CartModel(
              id       : product.id,
              name     : product.name,
              price    : product.price,
              img      : product.img,
              quantity : quantity, //esta variable ya la estamos pasando como argumento, dentro de esta funcion
              isExist  : true,
              time     : DateTime.now().toString(),
              product: product,
              );
            });
        }else{
          Get.snackbar('ALERTA !', 'Necesitas agregar almenos 1 producto.');
        }
      }

    //Enviando datos, a nutrso Cart_repo , para listarlos en la memoria local del dispositivo 
    cartRepo.addToCartList(getItems);


      update();
    }

/* -------------------------------------------------------------------------- */
/*                   VERIFICA SI HAY ELEMENTOS EN EL CARRITO                  */
/* -------------------------------------------------------------------------- */
 bool existInCart( ProductModel product){
    if(_items.containsKey(product.id)){
      return true;
    }else{
      return false;
    }
  }


  /* -------------------------------------------------------------------------- */
  /*              OBTENEMOS LA CANTIDAD DE LOS ELEMENTOS AGREGADOS              */
  /* -------------------------------------------------------------------------- */
int getQuantity(ProductModel product){

    var quantity = 0;

    if(_items.containsKey(product.id)){
      _items.forEach((key, value) {
        if(key==product.id){
          quantity = value.quantity!;
        }
      });
    }
    return quantity;
  }


  int get totalItems{
    var totalQuantity = 0;

    _items.forEach((key, value) {
      totalQuantity = totalQuantity + value.quantity!;
    });

    return totalQuantity;
  }

  /* -------------------------------------------------------------------------- */
  /*   FUNCION QUE RETORNA TODO EL OBJETO ALMACENADO EN LA VARIABLE => _ITEMS   */
  /* -------------------------------------------------------------------------- */
  //retornamos una lista de todos los valores guardados en dicho objeto
  List<CartModel> get getItems{
    return _items.entries.map((e){
      //print(e);
      //e hace referencia al mismo tiempo a dos  variables / instancias de un map => int, y CartModel
      return e.value;
    }).toList();
  }


  int get totalAmount{
    var total = 0;
    
    _items.forEach((key, value) {
      total += value.quantity! * value.quantity!;
    });

    return total;
  }


  /* -------------------------------------------------------------------------- */
  /*                      ALMACENANDO DATA EN LOCALSTORAGE                      */
  /* -------------------------------------------------------------------------- */

  List<CartModel> getCartData(){

    setCart = cartRepo.getCartList();

    return storageItems;
  }

  set setCart( List<CartModel> items){
    storageItems = items;
    //print('La cantidad de items en el carrito: ' + storageItems.length.toString());
    for( int i = 0; i <storageItems.length; i++ ){
      _items.putIfAbsent( storageItems[i].product!.id!, () => storageItems[i]);
    }
  }


/* -------------------------------------------------------------------------- */
/*                          SET DATA , AFTER CHECKOUT                         */
/* -------------------------------------------------------------------------- */

void addToHistory(){
  cartRepo.addTocartHistoryList();
  clear();
}


/* -------------------------------------------------------------------------- */
/*                         ELIMINANDO DATA DEL CARRITO                        */
/* -------------------------------------------------------------------------- */
void clear(){
  _items = {};
  update();
}

List<CartModel> getCartHistoryList(){
  return cartRepo.getCartHistoryList();
}


set setItems( Map<int ,CartModel> setItems){
  _items = {};
  _items = setItems;
}

void addToCartList(){
  cartRepo.addToCartList(getItems);
  update();
}

void clearCartHistory(){
  cartRepo.clearCartHistory();
  update();
}
  

}