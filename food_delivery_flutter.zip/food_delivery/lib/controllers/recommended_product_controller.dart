

import 'package:food_delivery/data/repository/popular_product_repo.dart';
import 'package:food_delivery/data/repository/recommended_product_repo.dart';
import 'package:food_delivery/models/products_model.dart';
import 'package:get/get.dart';

class RecommendedProductController extends GetxController{

  //Variable - instancias donde nos comunicamos con nuestro servicios y accedemos a todos sus metodos..
  final RecommendedProductRepo recommendedProductRepo;

  RecommendedProductController({required this.recommendedProductRepo});

  List<dynamic> _recommendedProductList = [];

  List<dynamic> get recommendedProductList => _recommendedProductList;

  bool _isLoadaded = false;
  bool get isLoaded => _isLoadaded;

  Future<void> getRecommendedProductList() async{
    //recibiendo las respuesta, del metodo GEt, del servicio 
    Response response = await recommendedProductRepo.getRecommendedProductList();
    if( response.statusCode == 200){
      //print('Consumo api correctO recomendables');
      //Si se consumio el endpoint de manera correcta, guarda la respuesta en la variable privada
      _recommendedProductList = [];
      _recommendedProductList.addAll(Product.fromJson(response.body).products);
      //print(_popularProductList);
      _isLoadaded = true;
      update();
    }else{
      //print('Consumo api correctO recomendables');
    }
  }

}