

import 'dart:convert';

import 'package:food_delivery/models/cart_model.dart';
import 'package:food_delivery/utils/app_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CartRepo{

  final SharedPreferences sharedPreferences;
  
  CartRepo( { required this.sharedPreferences } );


  List<String> cart = [];

  List<String> cartHistory = [];

  /* -------------------------------------------------------------------------- */
  /*                    RECIBIENDO DATOS DESDE EL CONTROLADOR                   */
  /* -------------------------------------------------------------------------- */
  
  void addToCartList( List<CartModel> cartList){

/*     sharedPreferences.remove( AppConstants.CART_LIST);
    sharedPreferences.remove( AppConstants.CART_HISTORY_LIST);
    return; */

    //convirtiendo el objeto a string
    cart = [];
    
    var time = DateTime.now().toString();

    cartList.forEach((element) { 
      /* -------------------------------------------------------------------------- */
      /*                      AÑADIENDO TIEMPO A CADA ELEMENTO                      */
      /* -------------------------------------------------------------------------- */
      element.time = time;
      return cart.add(jsonEncode(element));
    });

    //Pasando el string a nuestra memoria local
    sharedPreferences.setStringList(AppConstants.CART_LIST, cart);
    //print(sharedPreferences.getStringList(AppConstants.CART_LIST));
    //getCartList();
  }

  /* -------------------------------------------------------------------------- */
  /*            OBJETO A JSON  => A NUESTRO ARRAY VACIOS => cart = []           */
  /* -------------------------------------------------------------------------- */
  
  List<CartModel> getCartList(){

    List<String> carts = [];
    

    if( sharedPreferences.containsKey(AppConstants.CART_LIST) ){
      carts = sharedPreferences.getStringList(AppConstants.CART_LIST)!;
      //print('dentro de .. getCartList: '+carts.toString());
    }

    List<CartModel> cartList = [];
    //String a objeto
    carts.forEach((element) {
       cartList.add(CartModel.fromJson(jsonDecode(element)));
     });
    
    return cartList;
  }


//SET DATA AFTER CHECKOUT PT2
List<CartModel> getCartHistoryList(){
  if( sharedPreferences.containsKey(AppConstants.CART_HISTORY_LIST) ){
    cartHistory = [];
    cartHistory = sharedPreferences.getStringList(AppConstants.CART_HISTORY_LIST)!;
  }

  //Convirtiendo el string, a una lista de objetos
  List<CartModel> cartListHistory = [];

  cartHistory.forEach((element) => cartListHistory.add(CartModel.fromJson(jsonDecode(element))) );

  return cartListHistory;
}

/* -------------------------------------------------------------------------- */
/*                          SET DATA , AFTER CHECKOUT                         */
/* -------------------------------------------------------------------------- */

void addTocartHistoryList(){

  //Verifica que la lista de objetos del carrito NO VENGA VACÍA...
  if( sharedPreferences.containsKey(AppConstants.CART_HISTORY_LIST) ){
    cartHistory = sharedPreferences.getStringList(AppConstants.CART_HISTORY_LIST)!;
  }

  for( int i=0; i<cart.length; i++){
    //print('productos añadidos ,al presionar checkout : ' +cart[i]);
    cartHistory.add(cart[i]);
  }

  removeCart();

  sharedPreferences.setStringList(AppConstants.CART_HISTORY_LIST, cartHistory);

  print('el numero de elementos en el historial es : ' + getCartHistoryList().length.toString() );
  
  for( int j=0; j<getCartHistoryList().length; j++){
    print('el tiempo en que se realizo el pedido es : ' + getCartHistoryList()[j].time.toString() );
  }

}

/* -------------------------------------------------------------------------- */
/*                         ELIMINANDO DATA DEL CARRITO                        */
/* -------------------------------------------------------------------------- */

void removeCart(){
  cart = [];
  sharedPreferences.remove(AppConstants.CART_LIST);
}

void clearCartHistory(){
  removeCart();
  cartHistory = [];
  sharedPreferences.remove(AppConstants.CART_HISTORY_LIST);
}

}



