
import 'package:food_delivery/data/api/api_client.dart';
import 'package:food_delivery/utils/app_constants.dart';
import 'package:get/get.dart';

class RecommendedProductRepo extends GetxService{
  
  final ApiClient apiClient;

  RecommendedProductRepo({required this.apiClient});
  //Constructor con dicha variable

  //Endpoint Get donde se va a consumir informacion....
  Future<Response> getRecommendedProductList() async{
    return await apiClient.getData(AppConstants.RECOMMENDED_PRODUCT_URI);
  }
}